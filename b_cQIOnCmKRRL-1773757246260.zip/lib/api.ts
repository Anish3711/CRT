// API service layer - connects admin app to the student server
const STUDENT_SERVER = "https://vm-vnopscoz1wgbsxdf86mguc.vusercontent.net"

// ---- Types ----

export type Exam = {
  id: string
  title: string
  description: string
  type: "mcq" | "coding" | "mixed"
  duration: number
  startTime: string
  endTime: string
  maxAttempts: number
  status: "draft" | "published" | "active" | "completed"
  questionCount: number
  security: SecuritySettings
  createdAt: string
}

export type SecuritySettings = {
  forceFullscreen: boolean
  cancelOnTabSwitch: boolean
  disableCopyPaste: boolean
  disableRightClick: boolean
  disableDevTools: boolean
  enableScreenRecording: boolean
  enableWebcamMonitoring: boolean
  randomizeQuestions: boolean
  randomizeTestCases: boolean
}

export type MCQQuestion = {
  id: string
  questionText: string
  optionA: string
  optionB: string
  optionC: string
  optionD: string
  correctAnswer: "A" | "B" | "C" | "D"
  examId: string
  createdAt: string
}

export type TestCase = {
  id: string
  input: string
  expectedOutput: string
  isHidden: boolean
}

export type CodingProblem = {
  id: string
  title: string
  description: string
  inputFormat: string
  outputFormat: string
  constraints: string
  sampleInput: string
  sampleOutput: string
  testCases: TestCase[]
  allowedLanguages: string[]
  timeLimit: number
  memoryLimit: number
  examId: string
  createdAt: string
}

export type StudentAttempt = {
  id: string
  studentName: string
  rollNumber: string
  examId: string
  examName: string
  currentQuestion: number
  totalQuestions: number
  suspiciousCount: number
  status: "active" | "completed" | "terminated"
  score: number
  correctAnswers: number
  wrongAnswers: number
  timeTaken: string
  submissionTime: string
  activityLogs: ActivityLog[]
}

export type ActivityLog = {
  id: string
  type: "tab_switch" | "fullscreen_exit" | "copy_attempt" | "paste_attempt"
  timestamp: string
  description: string
}

export type CodingSubmission = {
  id: string
  studentName: string
  problemTitle: string
  language: string
  code: string
  testCasesPassed: number
  testCasesFailed: number
  executionTime: string
  memoryUsage: string
}

export const defaultSecurity: SecuritySettings = {
  forceFullscreen: true,
  cancelOnTabSwitch: true,
  disableCopyPaste: true,
  disableRightClick: true,
  disableDevTools: true,
  enableScreenRecording: false,
  enableWebcamMonitoring: false,
  randomizeQuestions: true,
  randomizeTestCases: false,
}

// ---- API Helpers ----

async function apiFetch<T>(path: string, options?: RequestInit): Promise<T> {
  const res = await fetch(`${STUDENT_SERVER}${path}`, {
    ...options,
    headers: {
      "Content-Type": "application/json",
      ...options?.headers,
    },
  })
  if (!res.ok) {
    const text = await res.text().catch(() => "Unknown error")
    throw new Error(`API Error ${res.status}: ${text}`)
  }
  return res.json()
}

// Use the local proxy API for server-side calls from client
async function localFetch<T>(path: string, options?: RequestInit): Promise<T> {
  const res = await fetch(`/api${path}`, {
    ...options,
    headers: {
      "Content-Type": "application/json",
      ...options?.headers,
    },
  })
  if (!res.ok) {
    const text = await res.text().catch(() => "Unknown error")
    throw new Error(`API Error ${res.status}: ${text}`)
  }
  return res.json()
}

// ---- Exam APIs ----

export const examApi = {
  getAll: () => localFetch<Exam[]>("/exams"),
  getById: (id: string) => localFetch<Exam>(`/exams/${id}`),
  create: (data: Omit<Exam, "id" | "createdAt" | "questionCount">) =>
    localFetch<Exam>("/exams", { method: "POST", body: JSON.stringify(data) }),
  update: (id: string, data: Partial<Exam>) =>
    localFetch<Exam>(`/exams/${id}`, { method: "PUT", body: JSON.stringify(data) }),
  delete: (id: string) =>
    localFetch<{ success: boolean }>(`/exams/${id}`, { method: "DELETE" }),
  publish: (id: string) =>
    localFetch<Exam>(`/exams/${id}/publish`, { method: "POST" }),
}

// ---- MCQ Question APIs (per-exam) ----

export const questionApi = {
  getByExam: (examId: string) => localFetch<MCQQuestion[]>(`/exams/${examId}/questions`),
  create: (examId: string, data: Omit<MCQQuestion, "id" | "createdAt" | "examId">) =>
    localFetch<MCQQuestion>(`/exams/${examId}/questions`, { method: "POST", body: JSON.stringify(data) }),
  update: (examId: string, qId: string, data: Partial<MCQQuestion>) =>
    localFetch<MCQQuestion>(`/exams/${examId}/questions/${qId}`, { method: "PUT", body: JSON.stringify(data) }),
  delete: (examId: string, qId: string) =>
    localFetch<{ success: boolean }>(`/exams/${examId}/questions/${qId}`, { method: "DELETE" }),
}

// ---- Coding Problem APIs (per-exam) ----

export const codingApi = {
  getByExam: (examId: string) => localFetch<CodingProblem[]>(`/exams/${examId}/coding`),
  create: (examId: string, data: Omit<CodingProblem, "id" | "createdAt" | "examId">) =>
    localFetch<CodingProblem>(`/exams/${examId}/coding`, { method: "POST", body: JSON.stringify(data) }),
  update: (examId: string, pId: string, data: Partial<CodingProblem>) =>
    localFetch<CodingProblem>(`/exams/${examId}/coding/${pId}`, { method: "PUT", body: JSON.stringify(data) }),
  delete: (examId: string, pId: string) =>
    localFetch<{ success: boolean }>(`/exams/${examId}/coding/${pId}`, { method: "DELETE" }),
}

// ---- Student / Monitoring APIs ----

export const monitorApi = {
  getActiveSessions: (examId?: string) =>
    localFetch<StudentAttempt[]>(examId ? `/monitoring?examId=${examId}` : "/monitoring"),
  terminateSession: (attemptId: string) =>
    localFetch<{ success: boolean }>(`/monitoring/${attemptId}/terminate`, { method: "POST" }),
}

// ---- Results APIs ----

export const resultsApi = {
  getByExam: (examId?: string) =>
    localFetch<StudentAttempt[]>(examId ? `/results?examId=${examId}` : "/results"),
  getCodingSubmissions: (examId?: string) =>
    localFetch<CodingSubmission[]>(examId ? `/results/coding?examId=${examId}` : "/results/coding"),
}

// ---- Dashboard Stats ----

export type DashboardStats = {
  totalExams: number
  activeExams: number
  totalStudents: number
  averageScore: number
  recentExams: Exam[]
  recentAttempts: StudentAttempt[]
}

export const dashboardApi = {
  getStats: () => localFetch<DashboardStats>("/dashboard/stats"),
}
