import { NextRequest, NextResponse } from "next/server"

const STUDENT_SERVER = "https://vm-vnopscoz1wgbsxdf86mguc.vusercontent.net"

async function proxyToStudent(path: string, init?: RequestInit) {
  try {
    const res = await fetch(`${STUDENT_SERVER}${path}`, {
      ...init,
      headers: { "Content-Type": "application/json", ...init?.headers },
      signal: AbortSignal.timeout(8000),
    })
    const contentType = res.headers.get("content-type") || ""
    if (contentType.includes("application/json")) {
      return NextResponse.json(await res.json(), { status: res.status })
    }
    return NextResponse.json({ raw: await res.text() }, { status: res.status })
  } catch {
    return null
  }
}

export async function POST(
  _req: NextRequest,
  { params }: { params: Promise<{ attemptId: string }> }
) {
  const { attemptId } = await params
  const proxy = await proxyToStudent(`/api/monitoring/${attemptId}/terminate`, { method: "POST" })
  if (proxy) return proxy
  return NextResponse.json({ error: "Student server unreachable" }, { status: 502 })
}
