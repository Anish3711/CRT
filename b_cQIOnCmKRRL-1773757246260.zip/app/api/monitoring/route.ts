import { NextRequest, NextResponse } from "next/server"

const STUDENT_SERVER = "https://vm-vnopscoz1wgbsxdf86mguc.vusercontent.net"

async function proxyToStudent(path: string, init?: RequestInit) {
  try {
    const res = await fetch(`${STUDENT_SERVER}${path}`, {
      ...init,
      headers: { "Content-Type": "application/json", ...init?.headers },
      signal: AbortSignal.timeout(8000),
    })
    const contentType = res.headers.get("content-type") || ""
    if (contentType.includes("application/json")) {
      return NextResponse.json(await res.json(), { status: res.status })
    }
    return NextResponse.json({ raw: await res.text() }, { status: res.status })
  } catch {
    return null
  }
}

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url)
  const examId = searchParams.get("examId")
  const path = examId ? `/api/monitoring?examId=${examId}` : "/api/monitoring"
  const proxy = await proxyToStudent(path)
  if (proxy) return proxy
  return NextResponse.json([])
}
