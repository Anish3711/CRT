import { NextResponse } from "next/server"

const STUDENT_SERVER = "https://vm-vnopscoz1wgbsxdf86mguc.vusercontent.net"

async function proxyToStudent(path: string) {
  try {
    const res = await fetch(`${STUDENT_SERVER}${path}`, {
      headers: { "Content-Type": "application/json" },
      signal: AbortSignal.timeout(8000),
    })
    const contentType = res.headers.get("content-type") || ""
    if (contentType.includes("application/json")) {
      return await res.json()
    }
    return null
  } catch {
    return null
  }
}

export async function GET() {
  const stats = await proxyToStudent("/api/dashboard/stats")
  if (stats) {
    return NextResponse.json(stats)
  }

  // Build stats from individual endpoints
  const exams = (await proxyToStudent("/api/exams")) || []
  const monitoring = (await proxyToStudent("/api/monitoring")) || []
  const results = (await proxyToStudent("/api/results")) || []

  const examsArr = Array.isArray(exams) ? exams : []
  const monitoringArr = Array.isArray(monitoring) ? monitoring : []
  const resultsArr = Array.isArray(results) ? results : []

  const allAttempts = [...monitoringArr, ...resultsArr]
  const completedAttempts = allAttempts.filter(
    (a: { status: string }) => a.status === "completed"
  )
  const avgScore =
    completedAttempts.length > 0
      ? Math.round(
          completedAttempts.reduce(
            (acc: number, a: { score: number }) => acc + (a.score || 0),
            0
          ) / completedAttempts.length
        )
      : 0

  return NextResponse.json({
    totalExams: examsArr.length,
    activeExams: examsArr.filter((e: { status: string }) => e.status === "active").length,
    totalStudents: allAttempts.length,
    averageScore: avgScore,
    recentExams: examsArr.slice(0, 5),
    recentAttempts: allAttempts.slice(0, 5),
  })
}
