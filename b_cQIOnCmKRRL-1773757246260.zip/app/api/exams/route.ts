import { NextRequest, NextResponse } from "next/server"

const STUDENT_SERVER = "https://vm-vnopscoz1wgbsxdf86mguc.vusercontent.net"

async function proxyToStudent(path: string, init?: RequestInit) {
  try {
    const res = await fetch(`${STUDENT_SERVER}${path}`, {
      ...init,
      headers: { "Content-Type": "application/json", ...init?.headers },
      signal: AbortSignal.timeout(8000),
    })
    const contentType = res.headers.get("content-type") || ""
    if (contentType.includes("application/json")) {
      const data = await res.json()
      return NextResponse.json(data, { status: res.status })
    }
    const text = await res.text()
    return NextResponse.json({ raw: text }, { status: res.status })
  } catch {
    return null // server unreachable
  }
}

// GET /api/exams
export async function GET() {
  const proxy = await proxyToStudent("/api/exams")
  if (proxy) return proxy
  return NextResponse.json([])
}

// POST /api/exams - create exam
export async function POST(req: NextRequest) {
  const body = await req.json()
  const proxy = await proxyToStudent("/api/exams", {
    method: "POST",
    body: JSON.stringify(body),
  })
  if (proxy) return proxy
  return NextResponse.json({ error: "Student server unreachable" }, { status: 502 })
}
