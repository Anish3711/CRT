import { NextRequest, NextResponse } from "next/server"

const STUDENT_SERVER = "https://vm-vnopscoz1wgbsxdf86mguc.vusercontent.net"

async function proxyToStudent(path: string, init?: RequestInit) {
  try {
    const res = await fetch(`${STUDENT_SERVER}${path}`, {
      ...init,
      headers: { "Content-Type": "application/json", ...init?.headers },
      signal: AbortSignal.timeout(8000),
    })
    const contentType = res.headers.get("content-type") || ""
    if (contentType.includes("application/json")) {
      return NextResponse.json(await res.json(), { status: res.status })
    }
    return NextResponse.json({ raw: await res.text() }, { status: res.status })
  } catch {
    return null
  }
}

export async function GET(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params
  const proxy = await proxyToStudent(`/api/exams/${id}`)
  if (proxy) return proxy
  return NextResponse.json({ error: "Not found" }, { status: 404 })
}

export async function PUT(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params
  const body = await req.json()
  const proxy = await proxyToStudent(`/api/exams/${id}`, {
    method: "PUT",
    body: JSON.stringify(body),
  })
  if (proxy) return proxy
  return NextResponse.json({ error: "Student server unreachable" }, { status: 502 })
}

export async function DELETE(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params
  const proxy = await proxyToStudent(`/api/exams/${id}`, { method: "DELETE" })
  if (proxy) return proxy
  return NextResponse.json({ error: "Student server unreachable" }, { status: 502 })
}
