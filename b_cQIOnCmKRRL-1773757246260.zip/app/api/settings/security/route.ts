import { NextResponse } from "next/server"

const STUDENT_SERVER = "https://vm-vnopscoz1wgbsxdf86mguc.vusercontent.net"

export async function GET() {
  try {
    const res = await fetch(`${STUDENT_SERVER}/api/settings/security`)
    if (res.ok) {
      const data = await res.json()
      return NextResponse.json(data)
    }
    return NextResponse.json(null, { status: res.status })
  } catch {
    return NextResponse.json(null, { status: 502 })
  }
}

export async function PUT(req: Request) {
  try {
    const body = await req.json()
    const res = await fetch(`${STUDENT_SERVER}/api/settings/security`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    })
    if (res.ok) {
      const data = await res.json()
      return NextResponse.json(data)
    }
    return NextResponse.json({ error: "Failed to save" }, { status: res.status })
  } catch {
    return NextResponse.json({ error: "Server unreachable" }, { status: 502 })
  }
}
